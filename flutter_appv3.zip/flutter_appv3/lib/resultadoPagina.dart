import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class MyWidget extends StatefulWidget {
  @override
  _MyWidgetState createState() => _MyWidgetState();
}

class _MyWidgetState extends State<MyWidget> {
  var data;

  @override
  void initState() {
    super.initState();
    getData();
  }

  Future<void> getData() async {
    var url = 'http://127.0.0.1:8000';
    var response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      setState(() {
        data = response.body;
      });
    } else {
      print('Error: ${response.statusCode}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text(data ?? 'Cargando datos...'),
    );
  }
}