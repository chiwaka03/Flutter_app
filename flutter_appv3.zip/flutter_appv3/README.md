Estos son los pasos que tiene que seguir para ejecutar el codigo, yo lo voy a explicar para android studio ya que ya traia los emuladores de movil:

- Tener descagado la SDK de flutter (esto es obligatorio para los dos framworks)
- Aqui tienes un video de como instalar el flutter en Visual Studio Code: https://www.youtube.com/watch?v=NF6kQJY5kL4
- Aqui tienes un video de como instalar flutter en android studio: https://www.youtube.com/watch?v=ozyzWJxHLwY
- Yo prefiero android studio porque ya trae el emulador
- Despues tienes que descargar las dependencias con pub get en mi caso es: --no-color pub get
- Al iniciar el codigo te puede dar algun problema tienes que poner esto al correr el codigo: --no-sound-null-safety